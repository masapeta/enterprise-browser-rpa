"""
Structured Logging — JSON-formatted logs for observability.

Usage in other modules:
    from app.core.logger import get_logger
    logger = get_logger(__name__)  # Gets a logger with the correct module name
    logger.info("event_name", key="value")
"""
import structlog
import logging
import sys
from app.core.config import settings


def configure_logger():
    """Configure structlog with JSON output and stdlib integration."""
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=settings.LOG_LEVEL,
    )

    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=False,  # Don't cache — each module gets its own name
    )


def get_logger(name: str = __name__):
    """
    Get a logger with the specified module name.
    Call as: logger = get_logger(__name__)
    """
    return structlog.get_logger(name)


# Default logger (for backwards compat)
logger = structlog.get_logger("app")
