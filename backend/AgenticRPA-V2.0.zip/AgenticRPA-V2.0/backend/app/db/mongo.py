"""
MongoDB client — async connection via Motor (async driver for PyMongo).
Used for persisting session history and audit trails.
"""
from motor.motor_asyncio import AsyncIOMotorClient
from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)


class Database:
    """Manages the async MongoDB connection."""

    def __init__(self):
        self.client: AsyncIOMotorClient = None
        self.db = None

    def connect(self):
        """Connect to MongoDB and select the database."""
        self.client = AsyncIOMotorClient(settings.MONGODB_URL)
        self.db = self.client[settings.MONGODB_DB_NAME]
        logger.info("mongodb_connected", url=settings.MONGODB_URL)

    def close(self):
        """Close the MongoDB connection."""
        if self.client:
            self.client.close()
            logger.info("mongodb_closed")
            self.client = None
            self.db = None


# Singleton instance
db = Database()


async def get_db():
    """Get the active MongoDB database. Used by endpoints that need persistence."""
    return db.db
