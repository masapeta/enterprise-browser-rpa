"""
Redis client — async connection management and pub/sub support.
Uses redis.asyncio for non-blocking operations.
"""
import redis.asyncio as aioredis
from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)


class RedisClient:
    """Manages the async Redis connection used for session state and pub/sub."""

    def __init__(self):
        self.redis: aioredis.Redis = None

    def connect(self):
        """Create the Redis connection pool (non-blocking, connects lazily)."""
        self.redis = aioredis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
        )
        logger.info("redis_connected", url=settings.REDIS_URL)

    async def close(self):
        """Close the Redis connection pool."""
        if self.redis:
            try:
                await self.redis.close()
                logger.info("redis_closed")
            except Exception as e:
                logger.error("redis_close_error", error=str(e))
            self.redis = None


# Singleton instance
redis_client = RedisClient()


async def get_redis() -> aioredis.Redis:
    """Get the active Redis connection. Used by endpoints and agent service."""
    return redis_client.redis
