import uvicorn
import sys
import asyncio
import subprocess

if __name__ == "__main__":
    if sys.platform == 'win32':
        # Revert back to WindowsSelectorEventLoopPolicy.
        # ProactorEventLoop has severe timeout bugs with large CDP payloads (screenshots), 
        # but SelectorEventLoop doesn't support asyncio.create_subprocess_exec.
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        
        # Monkey patch browser_use's LocalBrowserWatchdog to use a threaded subprocess.Popen
        # instead of the async event loop for launching Chrome, since SelectorEventLoop can't.
        import browser_use.browser.watchdogs.local_browser_watchdog as local_wd
        
        async def mock_create_subprocess_exec(*args, **kwargs):
            # Run the blocking Popen in a thread to keep async flow
            loop = asyncio.get_running_loop()
            
            def start_process():
                return subprocess.Popen(
                    args,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
            
            # This returns a Popen object. LocalBrowserWatchdog only needs its `.pid` attribute
            return await loop.run_in_executor(None, start_process)

        # Patch it only inside the local_browser_watchdog module
        local_wd.asyncio.create_subprocess_exec = mock_create_subprocess_exec

    print("Starting Uvicorn server (SelectorEventLoop active with subprocess monkey-patch)...")
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        loop="asyncio",
        reload=False
    )
