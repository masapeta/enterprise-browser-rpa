#!/bin/bash
set -e

echo "Starting VNC and noVNC setup..."

# Set display
export DISPLAY=:99

# Start Xvfb
Xvfb $DISPLAY -screen 0 1280x800x24 &
sleep 2

# Start Fluxbox (window manager)
fluxbox &
sleep 1

# Start x11vnc without password (for local development)
x11vnc -display $DISPLAY -nopw -listen localhost -xkb -ncache 10 -ncache_cr -geometry 1280x800 -forever &
sleep 2

# Start noVNC (websockify) to bridge VNC to WebSocket on port 6080
websockify --web /usr/share/novnc/ 6080 localhost:5900 &
sleep 2

echo "Starting FastAPI app..."
# Run Uvicorn backend
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
