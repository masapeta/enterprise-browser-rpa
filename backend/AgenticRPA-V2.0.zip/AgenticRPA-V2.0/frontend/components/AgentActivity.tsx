"use client";

import { useEffect, useRef, useState } from 'react';
import { WSMessage } from '../hooks/useWebSocket';

interface AgentStep {
    thought: string;
    action: string;
    url: string;
    step_number: number;
    timestamp: number;
}

interface AgentActivityProps {
    sessionId: string | null;
    stepMessages: WSMessage[];
    isConnected: boolean;
}

export default function AgentActivity({ sessionId, stepMessages, isConnected }: AgentActivityProps) {
    const endRef = useRef<HTMLDivElement>(null);
    const [vncAvailable, setVncAvailable] = useState<boolean>(false);

    useEffect(() => {
        // Check if VNC is available on port 6080 before trying to render the iframe
        fetch('http://localhost:6080/vnc.html', { mode: 'no-cors' })
            .then(() => setVncAvailable(true))
            .catch(() => setVncAvailable(false));
    }, []);

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [stepMessages.length]);

    // Derive current status from latest status message
    const latestStatus = [...stepMessages]
        .reverse()
        .find((m) => m.type === 'status');
    const status = latestStatus?.status || (sessionId ? 'waiting' : 'idle');

    // Collect step data
    const steps: AgentStep[] = stepMessages
        .filter((m) => m.type === 'step')
        .map((m, i) => ({
            thought: m.thought || '',
            action: m.action || '',
            url: m.url || '',
            step_number: m.step_number || i + 1,
            timestamp: Date.now(),
        }));

    const currentUrl = steps.length > 0 ? steps[steps.length - 1].url : '';

    if (!sessionId) {
        return (
            <div className="h-full flex flex-col items-center justify-center bg-gray-900 text-gray-600 gap-4">
                <svg className="w-16 h-16 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <div className="text-sm">Agent activity will appear here</div>
                <div className="text-xs text-gray-700">The browser window will open on your desktop</div>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col bg-gray-900 border-l border-gray-800">
            {/* Header Bar */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-900/80 backdrop-blur-sm z-10">
                <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-gray-300">Agent Live View</span>
                    <StatusBadge status={status} />
                </div>
                {currentUrl && (
                    <div className="flex items-center gap-2 px-3 py-1 bg-gray-800 rounded-lg border border-gray-700/50 max-w-[60%]">
                        <svg className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                        </svg>
                        <span className="text-xs text-gray-400 truncate">{currentUrl}</span>
                    </div>
                )}
            </div>

            {/* Split View: Browser top, Steps bottom */}
            <div className="flex-1 flex flex-col h-[calc(100%-48px)]">
                {/* 1. Live Browser View (noVNC when Docker, fallback for native) */}
                <div className="h-[60%] w-full border-b border-gray-800 bg-black relative flex items-center justify-center">
                    {vncAvailable && (
                        <iframe
                            src={`http://localhost:6080/vnc.html?autoconnect=true&resize=off&quality=9&compression=0`}
                            className="w-full h-full border-none pointer-events-auto absolute inset-0 z-10"
                            allow="clipboard-read; clipboard-write; fullscreen"
                            title="Live Agent Browser"
                            onLoad={(e) => {
                                // If iframe loaded successfully, show it
                                const target = e.target as HTMLIFrameElement;
                                target.style.opacity = '1';
                            }}
                            onError={() => { }}
                            style={{ opacity: 0 }}
                        />
                    )}

                    {/* Fallback shown underneath the iframe — visible when VNC isn't running */}
                    <div className="flex flex-col items-center justify-center text-center gap-3 p-6 z-0">
                        <svg className="w-14 h-14 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <div className="text-sm text-gray-400">Browser is running on your desktop</div>
                        <div className="text-xs text-gray-600 max-w-xs">
                            The agent controls a Chrome window directly on your machine.
                            To see the live view here, run via <code className="text-blue-400/70">docker-compose up</code>.
                        </div>
                    </div>

                    {/* Dark overlay when idle */}
                    {status === 'idle' && (
                        <div className="absolute inset-0 bg-gray-900/80 flex flex-col items-center justify-center backdrop-blur-sm z-10">
                            <svg className="w-12 h-12 text-gray-600 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <div className="text-sm text-gray-400">Browser inactive</div>
                        </div>
                    )}
                </div>

                {/* 2. Steps Timeline */}
                <div className="h-[40%] overflow-y-auto p-4 bg-gray-900 custom-scrollbar">
                    {steps.length === 0 && status !== 'idle' && (
                        <div className="flex items-center gap-3 text-gray-500 text-sm mt-4 justify-center">
                            <div className="w-5 h-5 border-2 border-blue-500/50 border-t-blue-500 rounded-full animate-spin" />
                            <span>Booting remote browser...</span>
                        </div>
                    )}

                    <div className="space-y-3">
                        {steps.map((step, i) => (
                            <div key={i} className="flex gap-3">
                                <div className="flex flex-col items-center">
                                    <div className="w-7 h-7 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-xs text-blue-400 font-mono flex-shrink-0">
                                        {step.step_number}
                                    </div>
                                    {i < steps.length - 1 && (
                                        <div className="w-px h-full bg-gray-800 mt-1" />
                                    )}
                                </div>

                                <div className="flex-1 pb-3 min-w-0">
                                    {step.thought && (
                                        <div className="mb-1.5">
                                            <span className="text-[10px] uppercase tracking-wider text-gray-600 font-semibold">Thinking</span>
                                            <p className="text-sm text-gray-400 mt-0.5 leading-relaxed">{step.thought}</p>
                                        </div>
                                    )}

                                    {step.action && (
                                        <div className="mt-1">
                                            <span className="text-[10px] uppercase tracking-wider text-gray-600 font-semibold">Action</span>
                                            <div className="mt-0.5 px-3 py-1.5 bg-gray-800/50 border border-gray-700/30 rounded-lg">
                                                <code className="text-xs text-emerald-400 break-all">{step.action}</code>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>

                    <div ref={endRef} />
                </div>
            </div>
        </div>
    );
}

function StatusBadge({ status }: { status: string }) {
    const config: Record<string, { color: string; label: string }> = {
        idle: { color: 'bg-gray-600', label: 'Idle' },
        waiting: { color: 'bg-yellow-500', label: 'Waiting' },
        running: { color: 'bg-blue-500 animate-pulse', label: 'Running' },
        completed: { color: 'bg-green-500', label: 'Completed' },
        failed: { color: 'bg-red-500', label: 'Failed' },
        cancelled: { color: 'bg-orange-500', label: 'Cancelled' },
    };
    const { color, label } = config[status] || config.idle;

    return (
        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-gray-800 border border-gray-700/50">
            <span className={`w-1.5 h-1.5 rounded-full ${color}`} />
            <span className="text-[11px] text-gray-400">{label}</span>
        </span>
    );
}
