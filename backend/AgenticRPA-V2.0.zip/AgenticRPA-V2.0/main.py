def main():
    print("Hello from agenticrpa-v2-0!")


if __name__ == "__main__":
    main()
