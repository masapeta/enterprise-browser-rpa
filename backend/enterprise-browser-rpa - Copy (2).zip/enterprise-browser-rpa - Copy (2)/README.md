# Enterprise Agentic RPA Platform

A browser automation platform powered by [browser-use](https://github.com/browser-use/browser-use) + LLMs. The agent understands web pages (text, buttons, inputs) and performs actions autonomously based on natural language instructions.

## 🚀 How It Works

1. You type a task in the chat UI (e.g., "Go to wikipedia.org and search for Python")
2. A **headful Chrome browser** opens on your desktop — you watch it live
3. The agent reads the page, decides what to click/type, executes actions
4. You see the agent's thinking and actions in the activity panel
5. Send follow-up instructions to the same session

## 📂 Project Structure
```text
/enterprise-browser-rpa
├── /backend
│   ├── /app
│   │   ├── main.py              # FastAPI app + lifespan
│   │   ├── agent_service.py     # browser-use integration + hooks
│   │   ├── /api/endpoints.py    # REST + WebSocket endpoints
│   │   ├── /core               # Config, session, logging
│   │   ├── /db                 # Redis + MongoDB clients
│   │   └── /worker/task_runner.py  # Async task launcher
│   ├── .env.example
│   └── requirements.txt
├── /frontend                    # Next.js dashboard
│   ├── /app/page.tsx           # Main layout
│   ├── /hooks/useWebSocket.ts  # Shared WS hook
│   └── /components
│       ├── ChatPanel.tsx       # Chat interface
│       └── AgentActivity.tsx   # Agent step timeline
└── docker-compose.yml
```

## 🛠️ Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+
- Redis running on localhost:6379
- MongoDB running on localhost:27017

### Backend
```bash
cd backend
pip install -r requirements.txt
playwright install chromium

# Configure your LLM provider
cp .env.example .env
# Edit .env — add your LLM_API_KEY

# Run
uvicorn app.main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — a Chrome window will open on your desktop when you send your first task.

## ⚙️ LLM Configuration

Edit `backend/.env`:

**Groq (fast, free tier)**
```ini
LLM_PROVIDER=groq
LLM_API_KEY=your_groq_key
LLM_MODEL=llama3-70b-8192
```

**OpenAI**
```ini
LLM_PROVIDER=openai
LLM_API_KEY=your_openai_key
LLM_MODEL=gpt-4-turbo-preview
```

**Azure OpenAI**
```ini
LLM_PROVIDER=azure
LLM_BASE_URL=https://your-resource.openai.azure.com/
LLM_API_KEY=your_key
LLM_MODEL=deployment_name
OPENAI_API_VERSION=2023-05-15
```

## 🏗️ Architecture

- **browser-use** handles all browser automation (DOM extraction, element selection, action execution, error recovery)
- **FastAPI** manages sessions, WebSocket connections, and async task launching
- **Redis** for real-time pub/sub (agent step updates) and session state
- **MongoDB** for durable audit trail
- **Single WebSocket** per session with structured message types (`chat`, `step`, `status`, `error`)
