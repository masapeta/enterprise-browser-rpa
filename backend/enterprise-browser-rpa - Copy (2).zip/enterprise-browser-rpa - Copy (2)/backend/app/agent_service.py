"""
Agent Service — wraps browser-use with lifecycle hooks for real-time updates.

This is the core integration layer between FastAPI and browser-use.
It manages browser-use Agent instances, handles step-by-step updates
via Redis pub/sub, and supports follow-up instructions with full session memory.

Architecture:
    FastAPI endpoint → AgentService.run_task() → browser-use Agent.run()
    Agent on_step_end hook → Redis pub/sub → WebSocket → Frontend

Session Memory:
    After each task completes, the agent's conversation history (thoughts,
    actions, URLs, extracted content) is stored in `session_history`.
    When a follow-up task arrives for an idle session, the history is
    injected into the new Agent via `extend_system_message`, giving
    the LLM full context of what happened before.
"""
import json
import asyncio
from dataclasses import dataclass, field
from typing import Optional
from browser_use import Agent, Browser
from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)
from app.db.redis import get_redis


# ---------------------------------------------------------------------------
# Session History — stores context between tasks for follow-up memory
# ---------------------------------------------------------------------------

@dataclass
class SessionContext:
    """
    Stores the accumulated context for a session across multiple tasks.

    This enables the follow-up flow:
        Task 1: "Search Amazon for keyboards" → agent finds keyboards
        Task 2: "Add the HyperX one to cart" → new agent knows about Task 1

    Attributes:
        tasks: List of task descriptions the user has given.
        thoughts: Agent's reasoning at each step (last N to avoid token overflow).
        actions: Actions taken (clicked X, typed Y, navigated to Z).
        urls_visited: URLs the agent has visited.
        extracted_content: Text content extracted from pages.
        final_answers: Final responses the agent gave for each task.
    """
    tasks: list[str] = field(default_factory=list)
    thoughts: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=list)
    urls_visited: list[str] = field(default_factory=list)
    extracted_content: list[str] = field(default_factory=list)
    final_answers: list[str] = field(default_factory=list)

    # Maximum items to retain per category (prevents token overflow)
    MAX_HISTORY_ITEMS = 15

    def add_from_agent(self, task: str, agent: Agent, final_answer: str):
        """
        Capture history from a completed agent run.

        Extracts thoughts, actions, URLs, and content from the agent's
        history object and appends them to the session context.
        Only keeps the last MAX_HISTORY_ITEMS to fit within LLM token limits.
        """
        self.tasks.append(task)
        self.final_answers.append(final_answer)

        # Extract history from browser-use agent
        try:
            for t in agent.history.model_thoughts():
                self.thoughts.append(str(t))
            for a in agent.history.model_actions():
                self.actions.append(str(a))
            for u in agent.history.urls():
                if u not in self.urls_visited:  # Deduplicate URLs
                    self.urls_visited.append(u)
            for c in agent.history.extracted_content():
                self.extracted_content.append(str(c)[:200])  # Truncate long content
        except Exception as e:
            logger.warning("history_capture_error", error=str(e))

        # Trim to prevent token overflow
        self._trim()

    def _trim(self):
        """Keep only the most recent items to stay within token limits."""
        self.thoughts = self.thoughts[-self.MAX_HISTORY_ITEMS:]
        self.actions = self.actions[-self.MAX_HISTORY_ITEMS:]
        self.urls_visited = self.urls_visited[-self.MAX_HISTORY_ITEMS:]
        self.extracted_content = self.extracted_content[-self.MAX_HISTORY_ITEMS:]

    def build_context_prompt(self) -> str:
        """
        Build a summary prompt for the LLM that captures previous session context.

        This is injected into the new Agent's system message via `extend_system_message`,
        so the LLM knows what happened in previous tasks without needing the full
        conversation history.

        Returns:
            A formatted string summarizing prior tasks, findings, and browser state.
            Returns empty string if no history exists.
        """
        if not self.tasks:
            return ""

        parts = [
            "\n--- PREVIOUS SESSION CONTEXT ---",
            "The user has been interacting with you in this session.",
            "Here is what happened in previous tasks:\n",
        ]

        # Summarize each completed task
        for i, (task, answer) in enumerate(zip(self.tasks, self.final_answers), 1):
            parts.append(f"Task {i}: \"{task}\"")
            parts.append(f"  Result: {answer[:300]}")  # Trim long answers
            parts.append("")

        # Key URLs visited (gives spatial context)
        if self.urls_visited:
            parts.append("URLs visited in this session:")
            for url in self.urls_visited[-5:]:  # Last 5 URLs only
                parts.append(f"  - {url}")
            parts.append("")

        # Recent actions (gives procedural context)
        if self.actions:
            parts.append("Recent actions taken:")
            for action in self.actions[-5:]:  # Last 5 actions
                parts.append(f"  - {action[:150]}")
            parts.append("")

        parts.append(
            "The browser is still open from the previous task. "
            "You can continue where the last task left off. "
            "The user's new instruction is a follow-up to the above context."
        )
        parts.append("--- END PREVIOUS CONTEXT ---\n")

        return "\n".join(parts)

    @property
    def has_history(self) -> bool:
        """Check if any history has been recorded."""
        return len(self.tasks) > 0


# ---------------------------------------------------------------------------
# LLM Provider Factory
# ---------------------------------------------------------------------------

def get_llm():
    """
    Create an LLM instance using browser-use's own LLM wrappers.

    IMPORTANT: browser-use requires LLMs that implement its BaseChatModel protocol,
    which includes .provider and .model attributes. Raw langchain classes (ChatOpenAI,
    ChatGroq) do NOT have these and will cause 'object has no attribute provider' errors.

    browser-use ships its own wrappers at:
        - browser_use.llm.groq.chat.ChatGroq
        - browser_use.llm.openai.chat.ChatOpenAI
        - browser_use.llm.azure.chat.ChatAzureOpenAI

    These wrap the native async clients (AsyncGroq, AsyncOpenAI) directly,
    bypassing langchain entirely.

    Returns:
        A browser-use BaseChatModel instance.
    """
    provider = settings.LLM_PROVIDER.lower()

    if provider == "azure":
        from browser_use.llm.azure.chat import ChatAzureOpenAI
        return ChatAzureOpenAI(
            model=settings.LLM_MODEL,
            api_key=settings.LLM_API_KEY,
            azure_endpoint=settings.LLM_BASE_URL,
            api_version=settings.OPENAI_API_VERSION or "2023-05-15",
            temperature=0.0,
        )
    else:
        # Works for: openai, groq, together, deepseek, etc.
        # We purposely use ChatOpenAI for Groq instead of ChatGroq because browser-use's
        # ChatGroq implementation strictly whitelists only 5 models for json_schema.
        # Since Groq's API is OpenAI compatible, ChatOpenAI works flawlessly.
        from browser_use.llm.openai.chat import ChatOpenAI
        return ChatOpenAI(
            model=settings.LLM_MODEL,
            api_key=settings.LLM_API_KEY,
            base_url=settings.LLM_BASE_URL,
            temperature=0.0,
        )


# ---------------------------------------------------------------------------
# Agent Service — core orchestration
# ---------------------------------------------------------------------------

class AgentService:
    """
    Manages browser-use Agent instances and streams step updates via Redis pub/sub.

    Session Memory Flow:
        1. User sends "Search Amazon for keyboards"
        2. Agent runs, finds keyboards, returns results
        3. History (thoughts, actions, URLs, results) saved in session_history[session_id]
        4. User sends "Add the HyperX to cart" (agent already finished)
        5. New Agent created WITH previous context via extend_system_message
        6. LLM sees: "Previously, you searched Amazon for keyboards and found..."
        7. Agent continues in the same browser, knowing what it did before

    Attributes:
        browser: Shared browser-use Browser instance (headful by default).
        active_agents: Map of session_id → running Agent instances.
        session_history: Map of session_id → SessionContext (persists between tasks).
    """

    def __init__(self):
        self.browser: Optional[Browser] = None
        self.active_agents: dict[str, Agent] = {}
        self.session_history: dict[str, SessionContext] = {}

    async def _ensure_browser(self):
        """Lazy browser initialization — creates browser on first use."""
        if self.browser is None:
            self.browser = Browser(
                headless=settings.HEADLESS,
                keep_alive=True # Prevents the browser window from closing after the first task
            )
            logger.info("browser_initialized", headless=settings.HEADLESS, keep_alive=True)

    def _get_or_create_context(self, session_id: str) -> SessionContext:
        """Get existing session context or create a new one."""
        if session_id not in self.session_history:
            self.session_history[session_id] = SessionContext()
        return self.session_history[session_id]

    async def close(self):
        """Gracefully shutdown — cancel active agents. Browser manages its own lifecycle."""
        for session_id in list(self.active_agents.keys()):
            logger.info("cancelling_agent_on_shutdown", session_id=session_id)

        # browser-use Browser is a Pydantic model that manages its own
        # Playwright lifecycle internally. We don't call .close() on it.
        self.browser = None

        # Clear all session history on shutdown
        self.session_history.clear()
        logger.info("agent_service_closed")

    async def run_task(self, session_id: str, task: str):
        """
        Run a browser-use agent for the given task.

        If this is a follow-up task (session has prior history), the previous
        context is injected into the Agent's system message so the LLM knows
        what happened before.

        Flow:
            1. Ensure browser is initialized
            2. Check for prior session context
            3. Create Agent with LLM + context
            4. Run agent with on_step_end hook
            5. Save history for future follow-ups
            6. Publish final result to chat

        Args:
            session_id: Unique session identifier for pub/sub routing.
            task: Natural language task description from the user.
        """
        await self._ensure_browser()
        redis = await get_redis()
        channel = f"session:{session_id}"

        # Get or create session context for memory persistence
        context = self._get_or_create_context(session_id)

        # Notify frontend that the agent has started
        is_followup = context.has_history
        await redis.publish(channel, json.dumps({
            "type": "status",
            "status": "running",
            "task": task,
            "is_followup": is_followup,
        }))

        if is_followup:
            logger.info(
                "followup_task_with_context",
                session_id=session_id,
                prior_tasks=len(context.tasks),
            )

        async def on_step_end(agent: Agent):
            """
            Lifecycle hook — fires after every agent step.
            Extracts the latest thought, action, and URL then publishes
            to Redis for real-time frontend updates.
            """
            try:
                history = agent.history.history
                if not history:
                    return

                # Get the last step
                last_step = history[-1]
                state = last_step.model_output.current_state if last_step.model_output else None
                action = last_step.model_output.action if last_step.model_output else []
                url = last_step.state.url if last_step.state else ""

                # Format thought safely
                thought_str = ""
                if state:
                    thought_str = state.thinking or state.next_goal or ""

                # Format action safely (it's a list of ActionModels)
                action_str = ""
                if action and len(action) > 0:
                    # convert ActionModel to dict and get the first non-None key
                    action_dict = action[0].model_dump(exclude_none=True)
                    if action_dict:
                        action_name = list(action_dict.keys())[0]
                        action_args = action_dict[action_name]
                        if isinstance(action_args, dict):
                            # simplify arguments (e.g. {'url': '...', 'new_tab': False} -> 'url: ...')
                            args_str = ", ".join(f"{k}='{v}'" for k, v in action_args.items())
                            action_str = f"{action_name}({args_str})"
                        else:
                            action_str = action_name

                msg = {
                    "type": "step",
                    "thought": thought_str,
                    "action": action_str,
                    "url": url,
                    "step_number": len(history),
                }
                await redis.publish(channel, json.dumps(msg))
            except Exception as e:
                logger.error("step_hook_error", session_id=session_id, error=str(e))

        try:
            # Build agent — inject prior context for follow-up tasks
            agent_kwargs = {
                "task": task,
                "llm": get_llm(),
                "browser": self.browser,
                "max_failures": settings.AGENT_MAX_FAILURES,
                "use_thinking": True,
            }

            # Aggressively reduce tokens for Groq to fit within strict free tier 8000 TPM limit
            is_groq = settings.LLM_PROVIDER.lower() == "groq"
            if is_groq:
                agent_kwargs.update({
                    "use_vision": False,
                    "max_history_items": 6,  # 6 is the minimum browser-use allows
                    "max_clickable_elements_length": 2000, # Hugely reduced from 5000
                    "include_attributes": ["title", "type", "name", "role", "href", "aria-label"], # Removed 'value', 'alt'
                })

            # Inject session memory if this is a follow-up
            if context.has_history:
                agent_kwargs["extend_system_message"] = context.build_context_prompt()

            agent = Agent(**agent_kwargs)
            self.active_agents[session_id] = agent

            result = await agent.run(
                on_step_end=on_step_end,
                max_steps=settings.AGENT_MAX_STEPS,
            )

            # Extract final answer natively from browser-use result
            final_text = ""
            if result:
                if result.final_result():
                    final_text = result.final_result()
                elif result.extracted_content():
                    # Fallback to the last extracted content if no final text was provided
                    final_text = "\n\n".join(result.extracted_content())

            if not final_text:
                final_text = "Task completed successfully, but the agent did not return a specific response string."

            # ---- SESSION MEMORY: Save history for future follow-ups ----
            context.add_from_agent(task, agent, final_text)
            logger.info(
                "history_saved",
                session_id=session_id,
                total_tasks=len(context.tasks),
                total_thoughts=len(context.thoughts),
            )

            # Publish final result to chat
            await redis.publish(channel, json.dumps({
                "type": "chat",
                "sender": "agent",
                "message": final_text,
            }))
            await redis.publish(channel, json.dumps({
                "type": "status",
                "status": "completed",
            }))
            logger.info("agent_completed", session_id=session_id)

        except asyncio.CancelledError:
            await redis.publish(channel, json.dumps({
                "type": "status",
                "status": "cancelled",
            }))
            logger.info("agent_cancelled", session_id=session_id)

        except Exception as e:
            error_msg = str(e)
            logger.error("agent_failed", session_id=session_id, error=error_msg)
            await redis.publish(channel, json.dumps({
                "type": "error",
                "message": f"Agent error: {error_msg}",
            }))
            await redis.publish(channel, json.dumps({
                "type": "status",
                "status": "failed",
            }))

        finally:
            self.active_agents.pop(session_id, None)

    async def send_followup(self, session_id: str, message: str) -> bool:
        """
        Send a follow-up task to a running agent.

        If the agent is currently active, uses add_new_task() which keeps
        the full conversation context automatically (best case).

        Args:
            session_id: Session to send the follow-up to.
            message: New task instruction.

        Returns:
            True if the agent was found and follow-up was queued, False otherwise.
        """
        agent = self.active_agents.get(session_id)
        if agent:
            agent.add_new_task(message)
            logger.info("followup_sent_to_active_agent", session_id=session_id)
            return True
        return False

    def is_agent_active(self, session_id: str) -> bool:
        """Check if an agent is currently running for this session."""
        return session_id in self.active_agents

    def clear_session_history(self, session_id: str):
        """Clear stored history for a session (e.g., when user starts fresh)."""
        self.session_history.pop(session_id, None)
        logger.info("session_history_cleared", session_id=session_id)


# Singleton — shared across the FastAPI application
agent_service = AgentService()
