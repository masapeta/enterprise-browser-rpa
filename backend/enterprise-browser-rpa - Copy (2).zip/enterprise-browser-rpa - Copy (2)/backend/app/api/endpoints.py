"""
API Endpoints — single WebSocket per session, structured message protocol.

Architecture:
    POST /sessions          → Create session + launch agent (async background task)
    GET  /sessions/{id}     → Get session state
    POST /sessions/{id}/cancel → Cancel a running agent
    WS   /sessions/{id}/ws  → Bidirectional updates (server→client: steps, chat, status;
                               client→server: follow-up instructions)

Message Types (server → client):
    {"type": "chat",   "sender": "agent", "message": "..."}
    {"type": "step",   "thought": "...", "action": "...", "url": "...", "step_number": N}
    {"type": "status", "status": "running|completed|failed|cancelled"}
    {"type": "error",  "message": "..."}

Message Format (client → server):
    Plain text or {"message": "follow-up instruction"}
"""
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
import asyncio
import json

from app.core.session import session_manager
from app.agent_service import agent_service
from app.worker.task_runner import task_runner
from app.db.redis import get_redis

router = APIRouter()


class CreateSessionRequest(BaseModel):
    """Request body for starting a new agent session."""
    task: str  # Natural language task description


class SessionResponse(BaseModel):
    """Response returned after session creation."""
    session_id: str
    status: str


@router.post("/sessions", response_model=SessionResponse)
async def create_session(request: CreateSessionRequest):
    """
    Create a new session and launch the browser-use agent.

    Steps:
        1. Create a session in Redis with a unique ID
        2. Launch the agent task as an asyncio background task
        3. Return the session_id immediately (agent runs async)
    """
    session_id = await session_manager.create_session()

    # Launch agent as async background task (replaces Celery .delay())
    task_runner.launch(
        session_id,
        agent_service.run_task(session_id, request.task),
    )

    return SessionResponse(session_id=session_id, status="running")


@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """Get the current state of a session from Redis."""
    data = await session_manager.get_session(session_id)
    if not data:
        raise HTTPException(status_code=404, detail="Session not found")
    return data


@router.post("/sessions/{session_id}/cancel")
async def cancel_session(session_id: str):
    """Cancel a running agent task."""
    cancelled = await task_runner.cancel(session_id)
    if cancelled:
        await session_manager.update_session(session_id, {"status": "cancelled"})
        return {"status": "cancelled"}
    raise HTTPException(status_code=404, detail="No active task for this session")


@router.post("/sessions/{session_id}/clear-history")
async def clear_session_history(session_id: str):
    """
    Clear the session's conversation memory.
    Use this when the user wants to start fresh without prior context.
    """
    agent_service.clear_session_history(session_id)
    return {"status": "history_cleared"}


@router.websocket("/sessions/{session_id}/ws")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """
    Single WebSocket per session — replaces the previous 3-WebSocket approach.

    This endpoint handles both directions concurrently:
      - relay_to_client: Forward Redis pub/sub messages to WebSocket client
      - receive_from_client: Accept follow-up instructions or new tasks

    Follow-up behavior:
      - If agent is active → sends follow-up via agent.add_new_task()
      - If agent is idle → starts a new agent run for this session

    Connection lifecycle:
      - Subscribes to Redis channel "session:{session_id}" on connect
      - Unsubscribes and cleans up on disconnect
    """
    await websocket.accept()
    redis = await get_redis()
    pubsub = redis.pubsub()

    channel = f"session:{session_id}"
    await pubsub.subscribe(channel)

    async def relay_to_client():
        """Forward Redis pub/sub messages → WebSocket client."""
        try:
            while True:
                # Non-blocking poll for new messages (100ms timeout)
                message = await pubsub.get_message(
                    ignore_subscribe_messages=True, timeout=0.1
                )
                if message and message["data"]:
                    data = message["data"]
                    if isinstance(data, bytes):
                        data = data.decode("utf-8")
                    try:
                        await websocket.send_text(data)
                    except Exception:
                        break  # Client disconnected

                # Small sleep to prevent busy-waiting
                await asyncio.sleep(0.05)
        except asyncio.CancelledError:
            pass

    async def receive_from_client():
        """Receive user messages and route to agent or start new task."""
        try:
            while True:
                text = await websocket.receive_text()
                if not text.strip():
                    continue

                # Parse message — accept JSON or plain text
                try:
                    msg = json.loads(text)
                    user_text = msg.get("message", text)
                except json.JSONDecodeError:
                    user_text = text

                # Route: follow-up if agent active, else new task
                if agent_service.is_agent_active(session_id):
                    await agent_service.send_followup(session_id, user_text)
                else:
                    task_runner.launch(
                        session_id,
                        agent_service.run_task(session_id, user_text),
                    )

        except WebSocketDisconnect:
            pass  # Normal disconnection
        except Exception:
            pass  # Unexpected errors — just close

    # Run both directions concurrently
    relay_task = asyncio.create_task(relay_to_client())
    recv_task = asyncio.create_task(receive_from_client())

    # Wait until either side completes (usually client disconnect)
    done, pending = await asyncio.wait(
        [relay_task, recv_task],
        return_when=asyncio.FIRST_COMPLETED,
    )

    # Clean up the other side
    for t in pending:
        t.cancel()

    await pubsub.unsubscribe(channel)
