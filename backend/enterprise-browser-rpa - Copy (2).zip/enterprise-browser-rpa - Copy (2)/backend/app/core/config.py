from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    PROJECT_NAME: str = "Enterprise Agentic RPA"
    VERSION: str = "2.0.0"

    # DATABASE
    MONGODB_URL: str = "mongodb://localhost:27017"
    MONGODB_DB_NAME: str = "rpa_platform"
    REDIS_URL: str = "redis://127.0.0.1:6379/0"

    # LLM
    LLM_PROVIDER: str = "groq"  # openai, groq, azure
    LLM_API_KEY: Optional[str] = None
    LLM_BASE_URL: Optional[str] = "https://api.groq.com/openai/v1"
    LLM_MODEL: str = "llama3-70b-8192"
    OPENAI_API_VERSION: Optional[str] = None  # for Azure

    # BROWSER
    HEADLESS: bool = False  # False = headful, visible Chrome window

    # AGENT
    AGENT_MAX_STEPS: int = 20
    AGENT_MAX_FAILURES: int = 3

    # LOGGING
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"


settings = Settings()
