"""
Session Manager — atomic Redis operations for session state management.

Uses Lua scripts for atomic updates to prevent race conditions
(the old code had GET-MODIFY-SET patterns that could lose data under concurrency).

Session data structure in Redis:
    Key:   "session:{uuid}"
    Value: JSON {session_id, created_at, updated_at, status, ...}
    TTL:   3600s (1 hour)

Step history is stored in a separate Redis list:
    Key:   "steps:{uuid}"
    Value: List of JSON step objects
    - Uses RPUSH (O(1) append) instead of re-serializing the entire step array
"""
import uuid
import json
import time
from typing import Optional, Dict, Any
from app.db.redis import get_redis

# Lua script for atomic session field updates.
# This replaces the old GET → modify in Python → SET pattern.
# The entire update happens server-side in Redis, preventing race conditions.
UPDATE_SESSION_LUA = """
local key = KEYS[1]
local updates_json = ARGV[1]
local ttl = tonumber(ARGV[2])

local current = redis.call('GET', key)
if not current then
    return nil
end

local data = cjson.decode(current)
local updates = cjson.decode(updates_json)

for k, v in pairs(updates) do
    data[k] = v
end
data['updated_at'] = tonumber(ARGV[3])

redis.call('SETEX', key, ttl, cjson.encode(data))
return cjson.encode(data)
"""


class SessionManager:
    """
    Manages session state in Redis with atomic operations.

    Each session has:
        - A main state key (JSON blob with metadata)
        - A steps list (separate key, O(1) appends)
    """
    PREFIX = "session:"
    STEPS_PREFIX = "steps:"
    TTL = 3600  # 1 hour

    async def create_session(self) -> str:
        """Create a new session with a unique ID. Returns the session_id."""
        session_id = str(uuid.uuid4())
        redis = await get_redis()
        initial_state = {
            "session_id": session_id,
            "created_at": time.time(),
            "status": "ready",
        }
        await redis.setex(
            f"{self.PREFIX}{session_id}",
            self.TTL,
            json.dumps(initial_state),
        )
        return session_id

    async def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve session data by ID. Returns None if expired or not found."""
        redis = await get_redis()
        data = await redis.get(f"{self.PREFIX}{session_id}")
        return json.loads(data) if data else None

    async def update_session(self, session_id: str, updates: Dict[str, Any]):
        """
        Atomically update session fields using a Lua script.

        This prevents race conditions — the entire read-modify-write
        happens in a single Redis operation, not in Python.

        Args:
            session_id: Session to update.
            updates: Dict of field names → new values to merge in.
        """
        redis = await get_redis()
        result = await redis.eval(
            UPDATE_SESSION_LUA,
            1,
            f"{self.PREFIX}{session_id}",
            json.dumps(updates),
            str(self.TTL),
            str(time.time()),
        )
        return json.loads(result) if result else None

    async def add_step(self, session_id: str, step_data: Dict[str, Any]):
        """
        Append a step to the session's step history.

        Uses RPUSH to a separate Redis list — O(1) append,
        no need to deserialize/re-serialize the entire step array.
        """
        redis = await get_redis()
        key = f"{self.STEPS_PREFIX}{session_id}"
        await redis.rpush(key, json.dumps(step_data))
        await redis.expire(key, self.TTL)

    async def get_steps(self, session_id: str):
        """Retrieve all steps for a session."""
        redis = await get_redis()
        key = f"{self.STEPS_PREFIX}{session_id}"
        raw_steps = await redis.lrange(key, 0, -1)
        return [json.loads(s) for s in raw_steps]


# Singleton instance
session_manager = SessionManager()
