"""
FastAPI Application Entry Point — Enterprise Agentic RPA Platform.

This module initializes the FastAPI app, configures middleware, and manages
the application lifespan (startup/shutdown of database connections and
the agent service).
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import sys

# Workaround for Python's asyncio Proactor pipe shutdown error on Windows
# specifically when using Playwright and Uvicorn together.
if sys.platform == 'win32':
    try:
         from asyncio.proactor_events import _ProactorBasePipeTransport
         old_del = _ProactorBasePipeTransport.__del__
         def silence_proactor_pipe_error(self):
             try:
                 old_del(self)
             except Exception:
                 pass
         _ProactorBasePipeTransport.__del__ = silence_proactor_pipe_error
    except Exception:
         pass

from app.core.config import settings
from app.core.logger import configure_logger, get_logger
from app.db.mongo import db
from app.db.redis import redis_client
from app.agent_service import agent_service

configure_logger()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.
    - Startup: connect to MongoDB, Redis
    - Shutdown: close agent service, disconnect from databases
    Note: Browser is NOT created here — it's lazily initialized on first task.
    """
    # Startup
    try:
        db.connect()
    except Exception as e:
        logger.warning("mongodb_connect_failed", error=str(e))

    try:
        redis_client.connect()
    except Exception as e:
        logger.error("redis_connect_failed", error=str(e))

    logger.info("app_started")

    yield  # App is running

    # Shutdown — close in reverse order
    try:
        await agent_service.close()
    except Exception as e:
        logger.error("agent_service_close_error", error=str(e))

    try:
        await redis_client.close()
    except Exception as e:
        logger.error("redis_close_error", error=str(e))

    try:
        db.close()
    except Exception as e:
        logger.error("mongo_close_error", error=str(e))

    logger.info("app_shutdown_complete")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan,
)

# CORS — allow frontend origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "message": "Enterprise Agentic RPA Platform API",
        "version": settings.VERSION,
        "status": "active",
    }


# Include API routes
from app.api.endpoints import router as api_router  # noqa: E402
app.include_router(api_router, prefix="/api/v1")
