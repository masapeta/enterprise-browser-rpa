"""
Async Task Runner — replaces Celery for agent task management.

Why not Celery?
    Celery workers block on long-lived async agent sessions, severely limiting
    concurrency. asyncio.create_task() lets us run multiple agents in the same
    event loop without process overhead.

Trade-off:
    All agents share the FastAPI process. For production scale-out, you'd move
    to a dedicated async worker (e.g., arq, or a separate process pool).
"""
import asyncio
from typing import Coroutine
from app.core.logger import get_logger

logger = get_logger(__name__)


class TaskRunner:
    """
    Tracks and manages running async agent tasks.

    Attributes:
        tasks: Dict mapping session_id → asyncio.Task
    """

    def __init__(self):
        self.tasks: dict[str, asyncio.Task] = {}

    def launch(self, session_id: str, coro: Coroutine):
        """
        Launch an agent coroutine as a background task.

        The task auto-removes itself from the dict when done
        via a done callback. This prevents memory leaks from
        accumulating finished tasks.
        """
        task = asyncio.create_task(coro, name=f"agent-{session_id}")
        self.tasks[session_id] = task

        def _cleanup(t: asyncio.Task):
            """Remove completed task from tracking dict."""
            self.tasks.pop(session_id, None)
            # Log if the task raised an unhandled exception
            if not t.cancelled() and t.exception():
                logger.error(
                    "task_unhandled_exception",
                    session_id=session_id,
                    error=str(t.exception()),
                )

        task.add_done_callback(_cleanup)
        logger.info("task_launched", session_id=session_id)

    async def cancel(self, session_id: str) -> bool:
        """
        Cancel a running task by session_id.

        Returns True if a task was found and cancelled, False otherwise.
        """
        task = self.tasks.get(session_id)
        if task and not task.done():
            task.cancel()
            logger.info("task_cancelled", session_id=session_id)
            return True
        return False

    def is_running(self, session_id: str) -> bool:
        """Check if a task is currently running for this session."""
        task = self.tasks.get(session_id)
        return task is not None and not task.done()

    def get_active_count(self) -> int:
        """Count of currently running agent tasks (useful for monitoring)."""
        return sum(1 for t in self.tasks.values() if not t.done())


# Singleton instance
task_runner = TaskRunner()
