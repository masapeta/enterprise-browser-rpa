"use client";

import { useState } from 'react';
import { useWebSocket, WSMessage } from '../hooks/useWebSocket';
import ChatPanel from '../components/ChatPanel';
import AgentActivity from '../components/AgentActivity';

export default function Home() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const { messages, sendMessage, isConnected } = useWebSocket(sessionId);

  // Filter messages by type for each panel
  const chatMessages = messages.filter(
    (m) => m.type === 'chat' || m.type === 'error'
  );
  const stepMessages = messages.filter(
    (m) => m.type === 'step' || m.type === 'status'
  );

  const handleSessionCreated = (id: string) => {
    setSessionId(id);
  };

  return (
    <main className="flex h-screen w-screen bg-gray-950 text-white overflow-hidden">
      {/* Chat Panel (left 35%) */}
      <div className="w-[35%] flex flex-col min-w-[320px] border-r border-gray-700/50 shadow-2xl z-20">
        <ChatPanel
          sessionId={sessionId}
          onSessionCreated={handleSessionCreated}
          chatMessages={chatMessages}
          sendMessage={sendMessage}
          isConnected={isConnected}
        />
      </div>

      {/* Agent Activity Panel (right 65%) */}
      <div className="w-[65%] flex flex-col bg-gray-900 overflow-hidden relative">
        <AgentActivity
          sessionId={sessionId}
          stepMessages={stepMessages}
          isConnected={isConnected}
        />
      </div>
    </main>
  );
}
