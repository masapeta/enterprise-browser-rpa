"use client";

import { useState, useEffect, useRef } from 'react';
import { WSMessage } from '../hooks/useWebSocket';

interface ChatMessage {
    id: string;
    sender: 'user' | 'agent' | 'system';
    text: string;
    timestamp: number;
}

interface ChatPanelProps {
    sessionId: string | null;
    onSessionCreated: (sessionId: string) => void;
    chatMessages: WSMessage[];
    sendMessage: (text: string) => void;
    isConnected: boolean;
}

export default function ChatPanel({
    sessionId,
    onSessionCreated,
    chatMessages,
    sendMessage,
    isConnected,
}: ChatPanelProps) {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    // Process incoming WebSocket messages
    useEffect(() => {
        if (chatMessages.length === 0) return;

        const latest = chatMessages[chatMessages.length - 1];
        const newMsg: ChatMessage = {
            id: Date.now().toString() + Math.random().toString(36),
            sender: latest.type === 'error' ? 'system' : (latest.sender || 'agent'),
            text: latest.message || latest.data || '',
            timestamp: Date.now(),
        };

        if (newMsg.text) {
            setMessages((prev) => [...prev, newMsg]);
            setLoading(false);
        }
    }, [chatMessages.length]);

    const handleSend = async () => {
        if (!input.trim()) return;

        const userText = input.trim();
        setInput('');

        // Show user message immediately
        setMessages((prev) => [
            ...prev,
            {
                id: Date.now().toString(),
                sender: 'user',
                text: userText,
                timestamp: Date.now(),
            },
        ]);

        if (!sessionId) {
            // First message — create session via REST
            setLoading(true);
            try {
                const res = await fetch('http://localhost:8001/api/v1/sessions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ task: userText }),
                });
                if (!res.ok) throw new Error('Failed to start session');
                const data = await res.json();
                onSessionCreated(data.session_id);
            } catch (err: any) {
                setMessages((prev) => [
                    ...prev,
                    {
                        id: Date.now().toString() + 'err',
                        sender: 'system',
                        text: `Error: ${err.message}`,
                        timestamp: Date.now(),
                    },
                ]);
                setLoading(false);
            }
        } else {
            // Follow-up — send via WebSocket
            setLoading(true);
            sendMessage(userText);
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-950">
            {/* Header */}
            <div className="p-4 border-b border-gray-800 bg-gradient-to-r from-gray-900 to-gray-950 shadow-lg">
                <div className="flex items-center justify-between">
                    <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                        Agentic RPA
                    </h1>
                    <div className="flex items-center gap-2">
                        {sessionId && (
                            <span
                                className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}
                            />
                        )}
                        <span className="text-xs text-gray-500">
                            {sessionId ? (isConnected ? 'Connected' : 'Reconnecting...') : 'Ready'}
                        </span>
                    </div>
                </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.length === 0 && (
                    <div className="text-gray-600 text-center mt-16 space-y-2">
                        <div className="text-4xl">🤖</div>
                        <div className="text-sm">Ask me to perform a browser task</div>
                        <div className="text-xs text-gray-700">
                            e.g. &quot;Go to wikipedia.org and search for Python&quot;
                        </div>
                    </div>
                )}
                {messages.map((msg) => (
                    <div
                        key={msg.id}
                        className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div
                            className={`max-w-[85%] px-4 py-2.5 shadow-md text-sm leading-relaxed ${msg.sender === 'user'
                                ? 'bg-blue-600 text-white rounded-2xl rounded-br-sm'
                                : msg.sender === 'system'
                                    ? 'bg-red-900/50 text-red-300 rounded-2xl rounded-bl-sm border border-red-800/50'
                                    : 'bg-gray-800 text-gray-100 rounded-2xl rounded-bl-sm border border-gray-700/50'
                                }`}
                        >
                            <div className="whitespace-pre-wrap">{msg.text}</div>
                        </div>
                    </div>
                ))}
                {loading && (
                    <div className="flex justify-start">
                        <div className="bg-gray-800 text-gray-400 px-4 py-2.5 rounded-2xl rounded-bl-sm border border-gray-700/50">
                            <div className="flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-800 bg-gray-950/80 backdrop-blur-sm">
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Type an instruction..."
                        className="flex-1 px-4 py-3 bg-gray-900 border border-gray-700/50 rounded-xl text-white text-sm outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 transition-all placeholder-gray-600"
                    />
                    <button
                        onClick={handleSend}
                        disabled={!input.trim()}
                        className="px-5 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-semibold text-sm text-white transition-all shadow-lg shadow-blue-600/20 disabled:opacity-30 disabled:shadow-none"
                    >
                        Send
                    </button>
                </div>
            </div>
        </div>
    );
}
