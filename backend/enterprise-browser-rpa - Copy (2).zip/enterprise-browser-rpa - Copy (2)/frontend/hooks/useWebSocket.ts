"use client";

import { useState, useEffect, useRef, useCallback } from 'react';

export interface WSMessage {
    type: 'chat' | 'step' | 'status' | 'error';
    [key: string]: any;
}

interface UseWebSocketReturn {
    messages: WSMessage[];
    sendMessage: (text: string) => void;
    isConnected: boolean;
}

export function useWebSocket(sessionId: string | null): UseWebSocketReturn {
    const [messages, setMessages] = useState<WSMessage[]>([]);
    const [isConnected, setIsConnected] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (!sessionId) return;

        let isCancelled = false;

        function connect() {
            if (isCancelled) return;

            const ws = new WebSocket(`ws://localhost:8001/api/v1/sessions/${sessionId}/ws`);
            wsRef.current = ws;

            ws.onopen = () => {
                setIsConnected(true);
                console.log('WebSocket connected');
            };

            ws.onmessage = (event) => {
                try {
                    const data: WSMessage = JSON.parse(event.data);
                    setMessages((prev) => [...prev, data]);
                } catch {
                    // Ignore unparseable messages
                }
            };

            ws.onclose = () => {
                setIsConnected(false);
                if (!isCancelled) {
                    // Auto-reconnect with backoff
                    reconnectTimeoutRef.current = setTimeout(connect, 2000);
                }
            };

            ws.onerror = () => {
                ws.close();
            };
        }

        connect();

        return () => {
            isCancelled = true;
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
            }
            if (wsRef.current) {
                wsRef.current.close();
            }
        };
    }, [sessionId]);

    const sendMessage = useCallback((text: string) => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(text);
        }
    }, []);

    return { messages, sendMessage, isConnected };
}
